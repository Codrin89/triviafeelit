var game;
function init() {
    game = 1;
    document.getElementById('name').value = '';
    document.getElementById('email').value = '';
    document.getElementById('phone').value = '';
    document.getElementById('game' + game).classList.add('show');
}
init();
var Config = {}

Config.getUrl = function() {
  return 'https://feelittrivia.herokuapp.com';
}

var XHR = {}

XHR.setCallback = function(callback) {
    this.xhttp = new XMLHttpRequest();
    var _self = this;
    this.xhttp.onreadystatechange = function() {
      if (_self.xhttp.readyState == 4 && _self.xhttp.status >= 200 && _self.xhttp.status <= 299) {
          console.log(_self);
        callback(_self.xhttp.responseText);
      }
    };
  }

XHR.POST = function(path, data, callback) {
    this.xhttp.open("POST", Config.getUrl() + path, true);
    this.xhttp.setRequestHeader("X-Parse-Application-Id", "feelittrivia");
    this.xhttp.setRequestHeader("Content-type", "application/json");
    this.xhttp.send(JSON.stringify(data));
}

XHR.GET = function(path, callback) {
    this.xhttp.open("GET", "https://cors-anywhere.herokuapp.com/" + Config.getUrl() + path, true);
    this.xhttp.setRequestHeader("X-Parse-Application-Id", "feelittrivia");
    this.xhttp.setRequestHeader("Content-type", "application/json");
    this.xhttp.send();
}

var ParseRequest = {};

ParseRequest.getData = function() {
    XHR.setCallback(function(data){
        buildGame();
    });
    XHR.GET('/upload');
}

ParseRequest.getData();

document.getElementById('button-submit').addEventListener('click', function() {
    var data = {
        name: document.getElementById('name').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value
    };
    XHR.POST('/parse/listings/uploadMedia', data);
});


function buildGame() {
    
}

